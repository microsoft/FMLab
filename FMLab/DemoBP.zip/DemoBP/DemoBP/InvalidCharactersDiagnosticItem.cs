﻿namespace DemoBP
{
    using System;
    using System.Collections.Generic;
    using System.Xml.Linq;
    using Microsoft.Dynamics.AX.Metadata.XppCompiler;

    public class InvalidCharactersDiagnosticItem : CustomDiagnosticItem
    { 
        private const string InvalidCharsKey = "chars";

        public const string DiagnosticMoniker = "InvalidCharacters";

        public InvalidCharactersDiagnosticItem(string path, string elementType, TextPosition textPosition, string invalidChars)
            : base(path, elementType, textPosition, DiagnosticType.BestPractices, Severity.Warning, DiagnosticMoniker, Messages.InvalidCharacters, invalidChars)
        {
            if (string.IsNullOrWhiteSpace(invalidChars))
            {
                throw new ArgumentNullException("invalidChars");
            }

            this.InvalidChars = invalidChars;
        }

        public string InvalidChars { get; private set; }

        public InvalidCharactersDiagnosticItem(XElement element)
            : base(element)
        {
        }

        protected override void ReadItemSpecificFields(System.Xml.Linq.XElement itemSpecificNode)
        {
            this.InvalidChars = base.ReadCustomField(itemSpecificNode, InvalidCharsKey);
        }

        protected override void WriteItemSpecificFields(System.Xml.Linq.XElement itemSpecificNode)
        {
            this.WriteCustomField(itemSpecificNode, InvalidCharsKey, this.InvalidChars);
        }
    }
}
