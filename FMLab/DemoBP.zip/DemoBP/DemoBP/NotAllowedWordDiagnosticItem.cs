﻿namespace DemoBP
{
    using System;
    using System.Collections.Generic;
    using System.Xml.Linq;
    using Microsoft.Dynamics.AX.Metadata.XppCompiler;

    public class NotAllowedWordDiagnosticItem : CustomDiagnosticItem
    { 
        private const string NotAllowedWordKey = "Word";

        public const string DiagnosticMoniker = "NotAllowedWord";

        public NotAllowedWordDiagnosticItem(string path, string elementType, TextPosition textPosition, string notAllowedWord)
            : base(path, elementType, textPosition, DiagnosticType.BestPractices, Severity.Warning, DiagnosticMoniker, Messages.NotAllowedWord, notAllowedWord)
        {
            if (string.IsNullOrWhiteSpace(notAllowedWord))
            {
                throw new ArgumentNullException("notAllowedWord");
            }

            this.NotAllowedWord = notAllowedWord;
        }

        public NotAllowedWordDiagnosticItem(Stack<Ast> context, TextPosition textPosition, string notAllowedWord)
            : base(context, textPosition, DiagnosticType.BestPractices, Severity.Warning, DiagnosticMoniker, Messages.NotAllowedWord, notAllowedWord)
        {
            if (string.IsNullOrWhiteSpace(notAllowedWord))
            {
                throw new ArgumentNullException("notAllowedWord");
            }

            this.NotAllowedWord = notAllowedWord;
        }

        public string NotAllowedWord { get; private set; }

        public NotAllowedWordDiagnosticItem(XElement element)
            : base(element)
        {
        }

        protected override void ReadItemSpecificFields(System.Xml.Linq.XElement itemSpecificNode)
        {
            this.NotAllowedWord = base.ReadCustomField(itemSpecificNode, NotAllowedWordKey);
        }

        protected override void WriteItemSpecificFields(System.Xml.Linq.XElement itemSpecificNode)
        {
            this.WriteCustomField(itemSpecificNode, NotAllowedWordKey, this.NotAllowedWord);
        }
    }
}
