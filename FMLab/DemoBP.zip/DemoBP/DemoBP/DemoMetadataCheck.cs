﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Dynamics.AX.Framework.BestPractices.Extensions;
using Microsoft.Dynamics.AX.Metadata.MetaModel;
using Microsoft.Dynamics.AX.Metadata.Upgrade.Common;

namespace DemoBP
{
     [BestPracticeRule(
        InvalidCharactersDiagnosticItem.DiagnosticMoniker,
        typeof(Messages),
        InvalidCharactersDiagnosticItem.DiagnosticMoniker + "Description",
        BestPracticeCheckerTargets.Table | BestPracticeCheckerTargets.View)]
    public class DemoMetadataCheck : BestPracticeMetadataChecker
    {
        private const string InvalidCharsCollection = "^+{}|";

        public override void RunChecksOn(Microsoft.Dynamics.AX.Metadata.Core.MetaModel.INamedObject metaObject)
        {
            AxTable table = metaObject as AxTable;
            
            // Cannot check if this is not a table
            if (table == null)
            {
                return;
            }

            if (table.Fields != null)
            {
                foreach (AxTableField field in table.Fields)
                {
                    this.VisitField(table.Name, field);
                }
            }
        }

        public void VisitField(string tableName, AxTableField field)
        {
            if (string.IsNullOrEmpty(field.HelpText))
            {
                return;
            }

            StringBuilder badChars = new StringBuilder();
            foreach (char c in field.HelpText)
            {
                if (InvalidCharsCollection.Contains(c))
                {
                    badChars.Append(c);
                }
            }

            if (badChars.Length != 0)
            {
                InvalidCharactersDiagnosticItem diagnostic = new InvalidCharactersDiagnosticItem(
                    ModelElementPathBuilder.CreatePathForTableField(tableName, field.Name),
                    "Table Field",
                    null,
                    badChars.ToString());

                this.ExtensionContext.AddErrorMessage(diagnostic);
            }
        }
    }
}
