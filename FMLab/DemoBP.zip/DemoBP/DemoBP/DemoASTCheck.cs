﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Dynamics.AX.Framework.BestPractices.Extensions;

namespace DemoBP
{
    [BestPracticeRule(
        NotAllowedWordDiagnosticItem.DiagnosticMoniker, 
        typeof(Messages), 
        NotAllowedWordDiagnosticItem.DiagnosticMoniker + "Description", 
        BestPracticeCheckerTargets.Class)]
    public class DemoASTCheck : BestPracticeAstChecker<BestPracticeCheckerPayload>
    {
        private const string NotAllowedWord = "Microsoft";

        protected override object VisitMethod(BestPracticeCheckerPayload payload, Microsoft.Dynamics.AX.Metadata.XppCompiler.Method method)
        {
            if (method != null)
            {
                if (method.Name.Contains(NotAllowedWord))
                {
                    NotAllowedWordDiagnosticItem diagnosticMessage = new NotAllowedWordDiagnosticItem(
                        this.Context,
                        method.MethodPosition,
                        NotAllowedWord);

                    this.ExtensionContext.AddErrorMessage(diagnosticMessage);
                }
            }

            return base.VisitMethod(payload, method);
        }
    }
}
